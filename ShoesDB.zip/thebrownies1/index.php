<?php
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);
error_reporting(0);
ini_set('display_errors', 0);
session_start();
require_once "./mvc/Bridge.php";
$myApp = new App();
?>