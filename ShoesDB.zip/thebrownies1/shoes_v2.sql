-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 03, 2022 at 05:34 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shoes_v2`
--

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `brand_id` int(11) NOT NULL,
  `brand_name` text DEFAULT NULL,
  `image` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`brand_id`, `brand_name`, `image`) VALUES
(1, 'jordan', 'brand1.jpg'),
(2, 'nike', 'brand2.jpg'),
(3, 'adidas', 'brand3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `colors`
--

CREATE TABLE `colors` (
  `color_id` int(11) NOT NULL,
  `color_name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `colors`
--

INSERT INTO `colors` (`color_id`, `color_name`) VALUES
(1, 'black'),
(2, 'blue'),
(3, 'red');

-- --------------------------------------------------------

--
-- Table structure for table `sizes`
--

CREATE TABLE `sizes` (
  `id` int(11) NOT NULL,
  `number` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sizes`
--

INSERT INTO `sizes` (`id`, `number`) VALUES
(1, '5'),
(2, '6'),
(3, '7');

-- --------------------------------------------------------

--
-- Table structure for table `sizes_specific_shoes`
--

CREATE TABLE `sizes_specific_shoes` (
  `size_shoes_id` int(11) NOT NULL,
  `size_id` int(11) NOT NULL,
  `specific_shoes_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sizes_specific_shoes`
--

INSERT INTO `sizes_specific_shoes` (`size_shoes_id`, `size_id`, `specific_shoes_id`) VALUES
(1, 1, 1),
(2, 2, 1),
(4, 2, 2),
(5, 3, 2),
(6, 1, 3),
(7, 2, 3),
(8, 3, 3),
(9, 2, 4),
(10, 3, 4),
(27, 1, 26),
(28, 2, 26),
(29, 3, 26),
(30, 1, 27),
(31, 2, 27),
(32, 2, 28),
(33, 3, 28),
(34, 1, 29),
(35, 2, 29),
(36, 3, 29),
(37, 2, 30),
(38, 3, 30),
(39, 1, 31),
(40, 2, 31),
(41, 3, 31),
(42, 2, 32),
(43, 3, 32),
(44, 1, 32),
(45, 2, 33),
(47, 1, 35),
(48, 3, 35),
(49, 1, 36),
(50, 2, 36);

-- --------------------------------------------------------

--
-- Table structure for table `specific_shoes`
--

CREATE TABLE `specific_shoes` (
  `id` int(11) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `name` text NOT NULL,
  `price` double NOT NULL,
  `image` text NOT NULL,
  `detail` text NOT NULL,
  `color_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `specific_shoes`
--

INSERT INTO `specific_shoes` (`id`, `brand_id`, `name`, `price`, `image`, `detail`, `color_id`) VALUES
(1, 1, 'max aura 4', 95, 'maxaura4_black.jpg', 'These Max Aura 4s feature a sleek and smooth design while offering great performance on the hardwood, asphalt, concrete or anywhere you want to hoop.', 1),
(2, 1, 'max aura 6', 95, 'maxaura6_red.jpg', 'The lightweight cushioning found in this next generation basketball shoe takes cues from its predecessors. Take flight on the court with timeless style and cloud-like heel support.', 3),
(3, 2, 'court borough mid 2', 65, 'courtmid_blue.jpg', 'Look like an all-star off the court with the Nike Court Borough Mid 2. The classic mid-top design is made with rich, durable leather and delicate stitching. Padding around the tongue and ankle helps keep you comfortable while you run, skip and jump throughout the day.', 2),
(4, 2, 'court borough low 2', 60, 'courtlow_red.jpg', 'Classic hoops styling teams up with a casual and comfortable design on theCourt Borough Low 2. Built for active kiddos who love a standout sneaker look, these shoes offer up the comfort they crave and the premium look they love.', 3),
(26, 3, 'X BAD BUNNY FORUM CORE BLACK', 160, 'X BAD BUNNY FORUM CORE BLACK_black.jpg', 'This offering of the adidas Forum Low comes constructed in a similar design featuring a mix of leather and suede in an all-Black color blocking. It also comes with its signature heavy-duty buckles, double-layered tongues with Bad Bunny’s third eye logo and bunny logo appearing on the translucent circle on the outsole.', 1),
(27, 3, 'NMD 360', 60, 'NMD 360_red.jpg', 'INFANT/TODDLER RUNNING SHOES\r\nThe NMD shoe model from Adidas continues to impress with its seamless blend of durability, style, and comfort. The knit upper sits on top of a molded EVA midsole and rubber outsole that provides excellent traction. Stability plugs are visible on either side of each shoe which serve as both a functional and fashionable piece. Coming in an illuminating Solar Red, your toddler will be the brightest crayon in the box!', 3),
(28, 2, 'AIR FLIGHT LITE MID', 130, 'AIR FLIGHT LITE MID_black.jpg', 'MENS LIFESTYLE SHOES\r\nOriginally one of the lightest performance basketball models to hit the court, the Nike Air Flight Lite Mid is the perfect addition to your casual rotation. Sumptuous leather uppers and plush padding offer comfy retro styling.', 1),
(29, 2, 'DUNK HIGH DARK BEETROOT', 125, 'DUNK HIGH DARK BEETROOT_red.jpg', 'MENS LIFESTYLE SHOES\r\nDressed in a Dark Beetroot and Wolf Grey color scheme. This offering of the Nike Dunk High comes constructed in a full leather build featuring a Grey base with Beetroot overlays, Swooshes, laces, and rubber outsole. The two colors are used on the branded areas completed with a White midsole.', 3),
(30, 2, 'DUNK HIGH OBSIDIAN', 100, 'DUNK HIGH OBSIDIAN_blue.jpg', 'GRADE SCHOOL LIFESTYLE SHOES\r\nThis offering of the Nike Dunk High comes constructed in a full leather build featuring an Obsidian base with Blue overlays and rubber outsole. White laces, Swooshes, and midsole completes the design.', 2),
(31, 1, 'ZION 2 HYPER ROYAL', 89, 'ZION 2 HYPER ROYAL_blue.jpg', 'MENS LIFESTYLE SHOES\r\nDressed in a Hyper Royal, White, and Black color scheme. This offering of the Jordan Zion 2 comes constructed in a mix of textile materials with cracked elephant print on the quarter overlay and “Zoom Air” branded forefoot strap. Personal branding on the tongues, insoles and carved into the toe of the outsole atop a new strobel unit in the midsole completes the design.', 2),
(32, 1, 'AIR JORDAN 6 RETRO METALLIC SILVER', 200, 'AIR JORDAN 6 RETRO METALLIC SILVER_black.jpg', 'MENS LIFESTYLE SHOES\r\nDressed in a Black and Metallic Silver color scheme. This Air Jordan 6 is basically a mid-top version of the Air Jordan 6 Low “Chrome” that was last seen back in 2015. It features a Black nubuck upper paired with Metallic Silver detailing atop a translucent outsole. The shoe will also come housed with special packaging.\r\n', 1),
(33, 2, 'AIR GRIFFEY MAX 1', 140, 'AIR GRIFFEY MAX 1_red.jpg', 'MENS LIFESTYLE SHOES\r\nThis offering of the Nike Air Griffey Max 1 features a Red leather base with Black nubuck overlays detailed with Navy Blue contrasting accents to give off that USA vibe. A White midsole atop a Black rubber outsole completes the design.', 3),
(35, 2, 'DUNK HIGH BLACK WHITE', 125, 'DUNK HIGH BLACK WHITE_black.jpg', 'Originally created for the hardwood, the Dunk later took to the streets—and as they say, the rest is history. More than 35 years after its debut, the silhouette still delivers bold, defiant style and remains a coveted look for crews across both sport and culture. Now, the university hoops OG returns covered in crisp material overlays with heritage-inspired colour blocking.', 1),
(36, 2, 'AIR JORDAN 1 ELEVATE LOW UNIVERSITY BLUE', 140, 'AIR JORDAN 1 ELEVATE LOW UNIVERSITY BLUE_blue.jpg', 'This women’s rendition of the Air Jordan 1 features a White leather base with University Blue overlays and Swooshes. A modified chunky platform sole in White atop a Blue rubber outsole with the outline of the “Wings” logo in the rear and cork insoles completes the design.', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`brand_id`);

--
-- Indexes for table `colors`
--
ALTER TABLE `colors`
  ADD PRIMARY KEY (`color_id`);

--
-- Indexes for table `sizes`
--
ALTER TABLE `sizes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sizes_specific_shoes`
--
ALTER TABLE `sizes_specific_shoes`
  ADD PRIMARY KEY (`size_shoes_id`),
  ADD KEY `size_specific` (`size_id`),
  ADD KEY `sizes_specific_shoes` (`specific_shoes_id`);

--
-- Indexes for table `specific_shoes`
--
ALTER TABLE `specific_shoes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `specific_generic` (`brand_id`),
  ADD KEY `colors_specific_shoes` (`color_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `brand_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `colors`
--
ALTER TABLE `colors`
  MODIFY `color_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `sizes`
--
ALTER TABLE `sizes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `sizes_specific_shoes`
--
ALTER TABLE `sizes_specific_shoes`
  MODIFY `size_shoes_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `specific_shoes`
--
ALTER TABLE `specific_shoes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `sizes_specific_shoes`
--
ALTER TABLE `sizes_specific_shoes`
  ADD CONSTRAINT `size_specific` FOREIGN KEY (`size_id`) REFERENCES `sizes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `sizes_specific_shoes` FOREIGN KEY (`specific_shoes_id`) REFERENCES `specific_shoes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `specific_shoes`
--
ALTER TABLE `specific_shoes`
  ADD CONSTRAINT `brands_specific_shoes` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`brand_id`),
  ADD CONSTRAINT `colors_specific_shoes` FOREIGN KEY (`color_id`) REFERENCES `colors` (`color_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
