<?php
class admin extends Controller
{
    function products()
    {
        $data1 = $this->model("brandsModel");
        $data2 = $this->model("productsModel");
        $brands = $data1->getAllBrands();
        if (!empty($_POST['condition'])) {
            $products = $data2->adminProducts($_POST['condition']);
        } else {
            $products = $data2->adminProducts('');
        }
        $this->view("admin_index", [
            "brands" => $brands,
            "products" => $products
        ]);
    }

    function add_product()
    {
        $data1 = $this->model("brandsModel");
        $data2 = $this->model("colorsModel");
        $data3 = $this->model("sizesModel");
        $brands = $data1->getAllBrands();
        $colors = $data2->getAllColors();
        $sizes = $data3->getAllsizes();
        $this->view("admin_add_product", [
            "brands" => $brands,
            "colors" => $colors,
            "sizes" => $sizes
        ]);
    }

    function brands()
    {
        $data1 = $this->model("brandsModel");
        if (!empty($_POST['brand_condition'])) {
            $brands = $data1->adminBrands($_POST['brand_condition']);
        } else {
            $brands = $data1->adminBrands('');
        }
        $this->view("admin_brands", [
            "brands" => $brands
        ]);
    }

    function add_brand()
    {
        $this->view("admin_add_brand");
    }

    function get_new_brand()
    {
        $data1 = $this->model("brandsModel");
        $lastIdBrand = $data1->getLastIdBrand();
        $image_id = $lastIdBrand + 1;
        if ($_FILES['image_brand']['size'] !== 0) {
            move_uploaded_file($_FILES['image_brand']['tmp_name'], "public/images/brands/brand" . $image_id . ".jpg");
        }
        if (isset($_POST['brand_name'])) {
            $brand_name = $_POST['brand_name'];
        }
        $data1->getNewBrand($brand_name, $image_id);
        redirect("http://localhost/thebrownies1/admin/brands");
    }

    function delete_brand($brand_id)
    {
        $data1 = $this->model("brandsModel");
        $data1->delete_brand($brand_id);
        redirect("http://localhost/thebrownies1/admin/brands");
    }

    function colors()
    {
        $data1 = $this->model("colorsModel");
        if (!empty($_POST['color_condition'])) {
            $colors = $data1->adminColors($_POST['color_condition']);
        } else {
            $colors = $data1->adminColors('');
        }
        $this->view("admin_colors", [
            "colors" => $colors
        ]);
        $this->view("admin_colors", [
            "colors" => $colors
        ]);
    }

    function add_color()
    {
        $this->view("admin_add_color");
    }

    function get_new_color()
    {
        $data1 = $this->model("colorsModel");
        if (isset($_POST['color_name'])) {
            $data1->get_new_color($_POST['color_name']);
        }
        ;
        redirect("http://localhost/thebrownies1/admin/colors");
    }

    function delete_color($color_id)
    {
        $data1 = $this->model("colorsModel");
        $data1->delete_color($color_id);
        redirect("http://localhost/thebrownies1/admin/colors");
    }

    function sizes()
    {
        $data1 = $this->model("sizesModel");
        $sizes = $data1->getAllsizes();
        $this->view("admin_sizes", [
            "sizes" => $sizes,
        ]);
    }

    function shoes_sizes()
    {
        $data1 = $this->model("sizesModel");
        $sizes = $data1->get_shoes_sizes();
        $this->view("admin_shoes_sizes", [
            "sizes" => $sizes,
        ]);
    }

    function add_new_product()
    {
        $data1 = $this->model("productsModel");
        $data2 = $this->model("colorsModel");
        $data3 = $this->model("sizesModel");
        if (isset($_POST['name'])) {
            $name = $_POST['name'];
        }
        if (isset($_POST['price'])) {
            $price = $_POST['price'];
        }
        if (isset($_POST['detail'])) {
            $detail = $_POST['detail'];
        }
        if (isset($_POST['brand_id'])) {
            $brand_id = $_POST['brand_id'];
        }
        if (isset($_POST['color_id'])) {
            $color_id = $_POST['color_id'];
        }
        //upload image
        $color_name = $data2->getNameColorbyId($color_id);
        if ($_FILES['image']['size'] !== 0) {
            move_uploaded_file($_FILES['image']['tmp_name'], "public/images/products/{$name}_{$color_name}.jpg");
        }
        $image = "{$name}_{$color_name}.jpg";
        $data1->get_new_product($brand_id, $name, $price, $image, $detail, $color_id);
        $lastShoesId = $data1->getLastShoesId();

        foreach ($_POST['size'] as $size) {
            // var_dump($size);
            $data3->get_new_shoes_size($size, $lastShoesId);
        }
        redirect("http://localhost/thebrownies1/admin/products");
    }

    function delete_product($shoes_id)
    {
        $data1 = $this->model("productsModel");
        $data1->delete_product($shoes_id);
        redirect("http://localhost/thebrownies1/admin/products");
    }

    function edit_product($shoes_id)
    {
        $data1 = $this->model("productsModel");
        $data2 = $this->model("colorsModel");
        $data3 = $this->model("brandsModel");
        $data4 = $this->model("sizesModel");
        $product = $data1->getShoesbyId($shoes_id);
        $brand = $data3->getBrandfromId($product[0]['brand_id']);
        $brands = $data3->getAllBrands();
        $colors = $data2->getAllColors();
        $color = $data2->getColorbyId($product[0]['color_id']);
        $size_number = $data4->getSizebyId($shoes_id);
        $sizes = $data4->getAllsizes();
        $this->view("admin_edit_product", [
            "product" => $product,
            "brand" => $brand,
            "color" => $color,
            "brands" => $brands,
            "colors" => $colors,
            "sizes" => $sizes,
            "size_number" => $size_number
        ]);
    }

    function edit_brand($brand_id)
    {
        $data1 = $this->model("brandsModel");
        $brand = $data1->getBrandfromId($brand_id);
        $this->view("admin_edit_brand", [
            'brand' => $brand
        ]);
    }

    function get_edit_brand($brand_id)
    {
        $data1 = $this->model("brandsModel");
        if (!empty($_FILES['image_brand'])) {
            move_uploaded_file($_FILES['image_brand']['tmp_name'], "public/images/brands/brand" . $brand_id . ".jpg");
            $data1->updateBrandwithImage($brand_id, $_POST['brand_name']);
        } else {
            $data1->updateBrandnoImage($brand_id, $_POST['brand_name']);
        }
        redirect("http://localhost/thebrownies1/admin/brands");
    }

    function edit_color($color_id)
    {
        $data1 = $this->model("colorsModel");
        $color = $data1->getcolorbyId($color_id);
        $this->view("admin_edit_color", [
            'color' => $color
        ]);
    }

    function get_edit_color($color_id)
    {
        $data1 = $this->model("colorsModel");
        $data1->updateColor($color_id, $_POST['color_name']);
        redirect("http://localhost/thebrownies1/admin/colors");
    }

    function get_edit_product($shoes_id)
    {
        $data1 = $this->model("productsModel");
        $data2 = $this->model("sizesModel");
        $data3 = $this->model("colorsModel");
        $shoes_name = $_POST['shoes_name'];
        $price = $_POST['price'];
        $detail = $_POST['detail'];
        $color_id = $_POST['color_id'];

        if (!empty($_FILES['image'])) {
            //upload image
            $color_name = $data3->getNameColorbyId($color_id);
            move_uploaded_file($_FILES['image']['tmp_name'], "public/images/products/{$shoes_name}_{$color_name}.jpg");
            $image = "{$shoes_name}_{$color_name}.jpg";
            $data1->updateProductwithimage($shoes_id, $shoes_name, $price, $detail, $color_id, $image);
        } else {
            $data1->updateProductnoimage($shoes_id, $shoes_name, $price, $detail, $color_id);
        }

        // put new size key or delete 
        $list_sizes_id = $_POST['sizes'];
        // var_dump($list_sizes_id);
        $list_sizes_id_int = [];
        foreach ($list_sizes_id as $size) {
            $size_num = (int) $size;
            array_push($list_sizes_id_int, $size_num);
        }
        //main arr 1
        // var_dump($list_sizes_id_int);

        $before_sizes = $data2->getSizebyId($shoes_id);
        // var_dump($before_sizes);
        $before_sizes_list = [];
        foreach ($before_sizes as $value) {
            array_push($before_sizes_list, $value['size_id']);
        }
        //main arr 2
        // var_dump($before_sizes_list);

        if (count($list_sizes_id_int) > count($before_sizes_list)) {
            $push_id = array_diff($list_sizes_id_int, $before_sizes_list);
            //main push diff 
            // var_dump($push_id);
            foreach ($push_id as $size_id) {
                $data2->get_new_shoes_size($size_id, $shoes_id);
            }
        } else {
            $push_id = array_diff($before_sizes_list, $list_sizes_id_int);
            //main push diff 
            // var_dump($push_id);
            foreach ($push_id as $size_id) {
                $data2->delete_shoes_size($size_id, $shoes_id);
            }
        }

        redirect("http://localhost/thebrownies1/admin/products");
    }

    function edit_size($size_id){
        $data1 = $this->model("sizesModel");
        $size = $data1->getOnesizeById($size_id);
        $this->view("admin_edit_size", [
            'size' => $size
        ]);
    }

    function get_edit_size($size_id){
        $data1 = $this->model("sizesModel");
        $number = $_POST['number'];
        $data1->update_size($size_id, $number);
        redirect("http://localhost/thebrownies1/admin/sizes");
    }

    function add_size()
    {
        $this->view("admin_add_size");
    }

    function get_new_size()
    {
        $data1 = $this->model("sizesModel");
        if (isset($_POST['size_name'])) {
            $data1->get_new_size($_POST['size_name']);
        }
        ;
        redirect("http://localhost/thebrownies1/admin/sizes");
    }

    function delete_size($size_id){
        $data1 = $this->model("sizesModel");
        $data1->delete_size($size_id);
        redirect("http://localhost/thebrownies1/admin/sizes");
    }
}
?>