<?php
// http://localhost/live/Home/Show/1/2

class products extends Controller
{
    function home()
    {
        $data1 = $this->model("brandsModel");
        $data2 = $this->model("productsModel");
        $brands = $data1->getAllBrands();
        $idbrand1 = $data1->getIdBrand("jordan");
        $idbrand2 = $data1->getIdBrand("nike");
        $products1 = $data2->getShoesByBrandId($idbrand1);
        $products2 = $data2->getShoesByBrandId($idbrand2);
        $this->view("index", [
            "brands" => $brands,
            "products1" => $products1,
            "products2" => $products2
        ]);
    }

    function shop()
    {
        $data1 = $this->model("brandsModel");
        $data2 = $this->model("productsModel");
        $data3 = $this->model("colorsModel");
        $data4 = $this->model("sizesModel");
        $brands = $data1->getAllBrands();
        $colors = $data3->getAllColors();
        $sizes = $data4->getAllsizes();
        $query = "SELECT * FROM specific_shoes WHERE 1";
        if (isset($_POST['brand'])) {
            // var_dump($_POST);
            if (count($_POST['brand']) > 0) {
                $brand_filter = implode("','", $_POST['brand']);
            } else
                $brand_filter = $_POST['brand'];
            $query .= " AND brand_id IN ('" . $brand_filter . "')";
        }
        if (isset($_POST['color'])) {
            if (count($_POST['color']) > 0) {
                $color_filter = implode("','", $_POST['color']);
            } else
                $color_filter = $_POST['color'];
            $query .= " AND color_id IN ('" . $color_filter . "')";
        }
        if (isset($_POST['price1'])) {
            $query .= " AND price BETWEEN 0 AND 70";
        }
        if (isset($_POST['price2'])) {
            $query .= " AND price BETWEEN 70 AND 150";
        }
        if (isset($_POST['price3'])) {
            $query .= " AND price > 150";
        }
        if (isset($_POST['size'])) {
            if (count($_POST['size']) > 0) {
                $size_filter = implode("','", $_POST['size']);
            } else
                $size_filter = $_POST['size'];
            $list_id = $data4->getShoesIdby($size_filter);
            // var_dump($list_id);
            $list_shoes_id = [];
            foreach ($list_id as $shoes) {
                $list_shoes_id[] = $shoes['specific_shoes_id'];
            }
            // print_r($list_shoes_id);
            if (count($list_shoes_id) > 0) {
                $size_filter = implode("','", $list_shoes_id);
            } else
                $size_filter = $list_shoes_id;
            $query .= " AND id IN ('" . $size_filter . "')";
        }
        if (isset($_POST['search_info'])) {
            $brand_id = $data1->getIdBrand($_POST['search_info']);
            $color_id = $data3->getIdcolor($_POST['search_info']);
            if (!empty($brand_id)) {
                $query .= " AND (name LIKE ('%" . $_POST['search_info'] . "%') OR detail LIKE ('%" . $_POST['search_info'] . "%') OR brand_id = {$brand_id})";
            } else if (!empty($color_id)) {
                $query .= " AND (name LIKE ('%" . $_POST['search_info'] . "%') OR detail LIKE ('%" . $_POST['search_info'] . "%') OR color_id = {$color_id})";
            } else if (!empty($color_id) && !empty($brand_id)) {
                $query .= " AND (name LIKE ('%" . $_POST['search_info'] . "%') OR detail LIKE ('%" . $_POST['search_info'] . "%') OR color_id = {$color_id} OR brand_id = {$brand_id})";
            } else {
                $query .= " AND (name LIKE ('%" . $_POST['search_info'] . "%') OR detail LIKE ('%" . $_POST['search_info'] . "%'))";
            }
        }
        if (isset($_POST['sortprice'])) {
            $query .= " AND ORDER BY price ASC";
        }
        // echo $query;
        $products = $data2->runQuery($query);
        $this->view("shop", [
            "brands" => $brands,
            "colors" => $colors,
            "sizes" => $sizes,
            "products" => $products
        ]);
    }

    public function shopby($brand_name)
    {
        $data1 = $this->model("brandsModel");
        $data2 = $this->model("productsModel");
        $data3 = $this->model("colorsModel");
        $data4 = $this->model("sizesModel");
        $brands = $data1->getAllBrands();
        $colors = $data3->getAllColors();
        $sizes = $data4->getAllsizes();
        $id_brand = $data1->getIdBrand($brand_name);
        $products = $data2->getShoesByBrandId($id_brand);

        $this->view("shop", [
            "brands" => $brands,
            "colors" => $colors,
            "sizes" => $sizes,
            "products" => $products
        ]);
    }

    public function viewproduct($id_pro)
    {
        $data1 = $this->model("brandsModel");
        $data2 = $this->model("productsModel");
        $data3 = $this->model("colorsModel");
        $data4 = $this->model("sizesModel");
        $brands = $data1->getAllBrands();
        $colors = $data3->getAllColors();
        $sizes = $data4->getAllsizes();
        $product = $data2->getShoesbyId($id_pro);
        $brand_name = $data1->getNameBrandfromId($product[0]['brand_id']);
        $size_id = $data4->getSizebyId($id_pro);
        // var_dump($product);
        // $size_number = [];
        if (count($size_id) > 0) {
            foreach ($size_id as $size) {
                $size_number[] = $data4->getSizenumberById($size['size_id']);
            }
        } else {
            $size_number = $data4->getSizenumberById($size_id['size_id']);
        }
        $color_name = $data3->getNameColorbyId($product[0]['color_id']);
        $relatedproducts = $data2->getShoesByBrandIdExcept($product[0]['brand_id'], $id_pro);
        $this->view("view", [
            "brands" => $brands,
            "colors" => $colors,
            "sizes" => $sizes,
            "brand_name" => $brand_name,
            "size_number" => $size_number,
            "color_name" => $color_name,
            "product" => $product,
            "relatedproducts" => $relatedproducts
        ]);
    }

    public function cart()
    {
        $data1 = $this->model("brandsModel");
        $brands = $data1->getAllBrands();
        $product_list = $_SESSION['cart_item'];
        $final_price = 0;
        foreach ($_SESSION['cart_item'] as $item) {
            $final_price += $item['total_each'];
        }
        $this->view("cart", [
            "brands" => $brands,
            "products" => $product_list,
            "final_price" => $final_price
        ]);
    }

    public function add_cart($shoes_id)
    {
        // unset($_SESSION['cart_item']);
        $total_price = 0;
        $total_each = 0;
        $data1 = $this->model("productsModel");
        $shoes = $data1->getShoesbyId($shoes_id);
        if (empty($_POST['quantity'])) {
            $_POST['quantity'] = 1;
        }

        if (empty($_POST['size'])) {
            $_POST['size'] = '6';
        }
        // var_dump($_POST);

        $quantity = (int) $_POST['quantity'];
        $total_each = $quantity * $shoes[0]['price'];
        // var_dump($total_each);

        $itemArr = ['id' => $shoes_id, 'price' => $shoes[0]['price'], 'name' => $shoes[0]['name'], 'image' => $shoes[0]['image'], 'total_each' => $total_each, 'size' => $_POST['size'], 'quantity' => $quantity];
        // var_dump($itemArr);

        if (!empty($_SESSION['cart_item'])) {
            array_push($_SESSION['cart_item'], $itemArr);

        } else {
            $_SESSION['cart_item'][0] = $itemArr;
        }
        redirect("http://localhost/thebrownies1/products/cart");
    }

    public function delete_cart($cart_id)
    {
        // session_unset();
        // var_dump($_SESSION);
        if (!empty($_SESSION['cart_item'])) {
            foreach ($_SESSION['cart_item'] as $k => $v) {
                if ($cart_id == $k) {
                    unset($_SESSION['cart_item'][$k]);
                }
                if (empty($_SESSION['cart_item'])) {
                    unset($_SESSION['cart_item']);
                }
            }
        }
        // print_r($_SESSION['cart_item']);
        redirect("http://localhost/thebrownies1/products/cart");
    }

}
?>