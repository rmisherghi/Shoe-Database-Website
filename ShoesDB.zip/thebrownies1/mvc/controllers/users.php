<?php
require_once "mvc/include/until.php";
class users extends Controller
{
    function login()
    {
        // check input and redirect to admin 
        $data1 = $this->model("brandsModel");
        $brands = $data1->getAllBrands();
        $this->view("login", [
            "brands" => $brands
        ]);
    }

    function get_login()
    {
        getAdmin($_POST['email'], $_POST['password']);
        if (
            isset($_SESSION['email']) && isset($_SESSION['password']) && !empty($_SESSION['email']) && !empty($_SESSION['password']) && $_SESSION['email'] == "admin@gmail.com" && $_SESSION['password'] == "admin"
        ) {
            redirect("http://localhost/thebrownies1/admin/products");
            session_unset();
        } else {
            redirect('http://localhost/thebrownies1/users/login');
        }
    }

    function contact(){
        $this->view("contact");
    }
}
?>