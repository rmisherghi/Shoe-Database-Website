<?php require_once "mvc/views/header.php"; ?>
<!-- form wrapper -->
<div class="container py-16">
    <div class="max-w-lg mx-auto shadow px-6 py-7 rounded overflow-hidden">
        <!-- Container for demo purpose -->
        <div class="container my-24 px-6 mx-auto">

            <!-- Section: Design Block -->
            <section class="text-gray-800">
                <div class="flex flex-wrap">
                    <div
                        class="grow-0 shrink-0 basis-auto md:mb-0 w-full md:w-full px-3 lg:px-6">
                        <h2 class="text-3xl font-bold mb-6">Contact us</h2>
                        <p class="text-gray-500 mb-6">
                            Lorem ipsum dolor sit amet consectetur adipisicing elit.
                            Laudantium, modi accusantium ipsum corporis quia asperiores
                            dolorem nisi corrupti eveniet dolores ad maiores repellendus enim
                            autem omnis fugiat perspiciatis? Ad, veritatis.
                        </p>
                        <p class="text-gray-500 mb-2">New York, 94126, United States</p>
                        <p class="text-gray-500 mb-2">+ 01 234 567 89</p>
                        <p class="text-gray-500">info@gmail.com</p>
                    </div>
                </div>
            </section>
            <!-- Section: Design Block -->

        </div>
        <!-- Container for demo purpose -->
    </div>
</div>
<!-- form wrapper end -->

<?php require_once "mvc/views/footer.php"; ?>