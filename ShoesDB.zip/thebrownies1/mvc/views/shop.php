<?php require_once "mvc/views/header.php"; ?>

<!-- breadcrum -->
<div class="container py-4 flex justify-between">
    <div class="flex gap-3 items-center">
        <a href="http://localhost/thebrownies1/" class="text-blue-900 text-base">
            <i class="fas fa-home"></i>
        </a>
        <span class="text-sm text-gray-400"><i class="fas fa-chevron-right"></i></span>
        <p class="text-gray-600 font-medium">Shop</p>
    </div>
</div>
<!-- breadcrum end -->

<!-- shop wrapper -->
<div class="container grid lg:grid-cols-4 gap-6 pt-4 pb-16 items-start relative">
    <!-- sidebar -->
    <div
        class="col-span-1 bg-white px-4 pt-4 pb-6 shadow rounded overflow-hidden absolute lg:static left-4 top-16 z-10 w-72 lg:w-full lg:block">
        <form class="divide-gray-200 divide-y space-y-5 relative"
            action="http://localhost/thebrownies1/products/shop" method="post">
            <!-- brand filter -->
            <div class="pt-4">
                <h3 class="text-xl text-gray-800 mb-3 uppercase font-medium">Brands</h3>
                <div class="space-y-2">
                    <!-- single brand name -->
                    <?php foreach ($data['brands'] as $brand) {
                        echo '
                        <div class="flex items-center">
                            <input type="checkbox" id="' . $brand['brand_name'] . '"
                                class="text-blue-900 focus:ring-0 rounded-sm cursor-pointer" value="' . $brand['brand_id'] . '" name="brand[]">
                            <label for="' . $brand['brand_name'] . '"
                                class="text-gray-600 ml-3 cursor-pointer uppercase">' . $brand['brand_name'] . '</label>
                            <div class="ml-auto text-gray-600 text-sm">(15)</div>
                        </div>
                        ';
                    } ?>
                    <!-- single brand name end -->
                </div>
            </div>
            <!-- brand filter end -->

            <!-- color filter -->
            <div class="pt-4">
                <h3 class="text-xl text-gray-800 mb-3 uppercase font-medium">colors</h3>
                <div class="space-y-2">
                    <!-- single color name -->
                    <?php foreach ($data['colors'] as $color) {
                        echo '
                        <div class="flex items-center">
                            <input type="checkbox" id="' . $color['color_name'] . '"
                                class="text-blue-900 focus:ring-0 rounded-sm cursor-pointer" value="' . $color['color_id'] . '" name="color[]">
                            <label for="' . $color['color_name'] . '"
                                class="text-gray-600 ml-3 cursor-pointer uppercase">' . $color['color_name'] . '</label>
                            <div class="ml-auto text-gray-600 text-sm">(15)</div>
                        </div>
                        ';
                    } ?>
                    <!-- single color name end -->
                </div>
            </div>
            <!-- color filter end -->

            <!-- price filter -->
            <div class="pt-4">
                <h3 class="text-xl text-gray-800 mb-3 uppercase font-medium">prices</h3>
                <div class="space-y-2">
                    <!-- single price name -->
                    <div class="flex items-center">
                        <input type="checkbox" id="price1"
                            class="text-blue-900 focus:ring-0 rounded-sm cursor-pointer"
                            value="price1" name="price1">
                        <label for="price1" class="text-gray-600 ml-3 cursor-pointer uppercase">
                            $0 - $70</label>
                    </div>
                    <!-- single price name end -->
                    <!-- single price name -->
                    <div class="flex items-center">
                        <input type="checkbox" id="price2"
                            class="text-blue-900 focus:ring-0 rounded-sm cursor-pointer"
                            value="price2" name="price2">
                        <label for="price2" class="text-gray-600 ml-3 cursor-pointer uppercase">
                            $70 - $150</label>
                    </div>
                    <!-- single price name end -->
                    <!-- single price name -->
                    <div class="flex items-center">
                        <input type="checkbox" id="price3"
                            class="text-blue-900 focus:ring-0 rounded-sm cursor-pointer"
                            value="price3" name="price3">
                        <label for="price3" class="text-gray-600 ml-3 cursor-pointer uppercase">
                            > $150</label>
                    </div>
                    <!-- single price name end -->
                </div>
            </div>
            <!-- price filter end -->

            <!-- size filter -->
            <div class="pt-4">
                <h3 class="text-xl text-gray-800 mb-3 uppercase font-medium">sizes</h3>
                <div class="space-y-2">
                    <!-- single size name -->
                    <?php foreach ($data['sizes'] as $size) {
                        echo '
                        <div class="flex items-center">
                            <input type="checkbox" id="' . $size['number'] . '"
                                class="text-blue-900 focus:ring-0 rounded-sm cursor-pointer" value="' . $size['id'] . '" name="size[]">
                            <label for="' . $size['number'] . '"
                                class="text-gray-600 ml-3 cursor-pointer uppercase">' . $size['number'] . '</label>
                            <div class="ml-auto text-gray-600 text-sm">(15)</div>
                        </div>
                        ';
                    } ?>
                    <!-- single size name end -->
                </div>
            </div>
            <!-- size filter end -->

            <!-- button filter -->
            <div class="pt-4 flex justify-center">
                <div class="flex items-center gap-2">
                    <input
                        class="bg-blue-800 hover:bg-blue-500 text-white font-bold py-2 px-4 border border-blue-700 rounded cursor-pointer"
                        type="submit" value="Filter"></input>
                    <!-- single button end -->
                </div>
            </div>
            <!-- button filter end -->
        </form>
    </div>
    <!-- sidebar end -->

    <!-- products -->
    <div class="col-span-3">
        <!-- sorting
        <form class="mb-4 flex items-center" method="post"
            action="http://localhost/thebrownies1/products/shop">
            <select
                class="w-44 text-sm text-gray-600 px-4 py-3 border-gray-300 shadow-sm rounded focus:ring-blue-800 focus:border-blue-800"
                name="sortprice">
                <option value="defaultprice">Default sorting</option>
                <option value="low_high">Price low-high</option>
                <option value="high_low">Price high-low</option>
            </select>
        </form>
        sorting end -->

        <!-- product wrapper -->
        <div class="grid lg:grid-cols-2 xl:grid-cols-3 sm:grid-cols-2 gap-6">
            <!-- single product -->
            <?php
            if (count($data['products']) == 0) {
                echo "NO DATA";
            } else {
                foreach ($data['products'] as $product) {
                    echo '
                <div class="group rounded bg-white shadow overflow-hidden">
                    <!-- product image -->
                    <div class="relative">
                        <img src="http://localhost/thebrownies1/public/images/products/' . $product['image'] . '" class="w-full lg:max-h-44">
                        <div
                            class="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center gap-2 opacity-0 group-hover:opacity-100 transition">
                            <a href="http://localhost/thebrownies1/products/viewproduct/'.$product['id'].'"
                                class="text-white text-lg w-9 h-9 rounded-full bg-blue-900 hover:bg-gray-800 transition flex items-center justify-center">
                                <i class="fas fa-search"></i>
                            </a>
                        </div>
                    </div>
                    <!-- product image end -->
                    <!-- product content -->
                    <div class="pt-4 pb-3 px-4">
                        <a href="http://localhost/thebrownies1/products/viewproduct/'.$product['id'].'">
                            <h4
                                class="uppercase font-medium text-xl mb-2 text-gray-800 hover:text-blue-900 transition">
                                ' . $product['name'] . '
                            </h4>
                        </a>
                        <div class="flex items-baseline mb-1 space-x-2">
                            <p class="text-xl text-blue-900 font-roboto font-semibold">$' . $product['price'] . '</p>
                        </div>
                        <div class="flex items-center">
    
                        </div>
                    </div>
                    <!-- product content end -->
                    <!-- product button -->
                    <a href="http://localhost/thebrownies1/products/add_cart/'.$product['id'].'"
                        class="block w-full py-1 text-center text-white bg-blue-900 border border-blue-900 rounded-b hover:bg-transparent hover:text-blue-900 transition">
                        Add to Cart
                    </a>
                    <!-- product button end -->
                </div>
                ';
                }
            } ?>
            <!-- single product end -->

        </div>
        <!-- product wrapper end -->
    </div>
    <!-- products end -->
</div>
<!-- shop wrapper end -->

<?php require_once "mvc/views/footer.php"; ?>