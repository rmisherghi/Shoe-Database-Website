<?php require_once "mvc/views/header.php"; ?>

<!-- banner -->
<div class="bg-cover bg-no-repeat bg-center py-36 relative"
    style="background-image: url('public/images/banner.jpg')">
    <div class="container">
        <!-- banner content -->
        <h1 class="xl:text-6xl md:text-5xl text-4xl text-gray-800 font-medium mb-4">
            The Brownies<br class="hidden sm:block">
        </h1>
        <p class="text-base text-gray-600 leading-6">
            The Brownies is one of the most-trusted athletic footwear
            <br class="hidden sm:block">
            retail chains in the United States.
        </p>
        <!-- banner button -->
        <div class="mt-12">
            <a href="http://localhost/thebrownies1/products/shop" class="bg-blue-800 border border-blue-800 text-white px-8 py-3 font-medium rounded-md uppercase hover:bg-transparent
               hover:text-blue-800 transition">
                Shop now
            </a>
        </div>
        <!-- banner button end -->
        <!-- banner content end -->
    </div>
</div>
<!-- banner end -->

<!-- categories -->
<div class="container py-16">
    <h2 class="text-2xl md:text-3xl font-medium text-gray-800 uppercase mb-6 text-center">shop by
        brand</h2>
    <div class="grid lg:grid-cols-3 sm:grid-cols-2 gap-3">
        <!-- single category -->
        <?php
        // var_dump($data['brands']); 
        foreach($data['brands'] as $brand){
            echo '            
            <div class="relative group rounded-sm overflow-hidden uppercase">
                <img src="http://localhost/thebrownies1/public/images/brands/'.$brand['image'].'" class="w-full max-h-60">
                <a href="http://localhost/thebrownies1/products/shopby/'.$brand['brand_name'].'" class="absolute inset-0 bg-black bg-opacity-40 group-hover:bg-opacity-50 flex items-center justify-center text-xl text-white font-roboto font-medium tracking-wide transition">
                    '.$brand['brand_name'].'
                </a>
            </div>
            ';
        }?>
        <!-- single category end -->

    </div>
</div>
<!-- categories end -->

<!-- top new arrival -->
<div class="container pb-16">
    <h2 class="text-2xl md:text-3xl font-medium text-gray-800 uppercase mb-6 text-center">jordan
    </h2>
    <!-- product wrapper -->
    <div class="grid lg:grid-cols-4 sm:grid-cols-2 gap-6">
        <!-- single product -->
        <?php foreach($data['products1'] as $product){
            echo '            
            <div class="group rounded bg-white shadow overflow-hidden">
                <!-- product image -->
                <div class="relative">
                    <img src="public/images/products/'.$product['image'].'" class="w-full lg:max-h-44">
                    <div
                        class="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center gap-2 opacity-0 group-hover:opacity-100 transition">
                        <a href="http://localhost/thebrownies1/products/viewproduct/'.$product['id'].'"
                            class="text-white text-lg w-9 h-9 rounded-full bg-blue-800 hover:bg-gray-800 transition flex items-center justify-center">
                            <i class="fas fa-search"></i>
                        </a>
                    </div>
                </div>
                <!-- product image end -->
                <!-- product content -->
                <div class="pt-4 pb-3 px-4">
                    <a href="http://localhost/thebrownies1/products/viewproduct/'.$product['id'].'">
                        <h4
                            class="uppercase font-medium text-xl mb-2 text-gray-800 hover:text-blue-800 transition">
                            '.$product['name'].'
                        </h4>
                    </a>
                    <div class="flex items-baseline mb-1 space-x-2">
                        <p class="text-xl text-blue-800 font-roboto font-semibold">$'.$product['price'].'</p>
    
                    </div>
    
                </div>
                <!-- product content end -->
                <!-- product button -->
                <a href="http://localhost/thebrownies1/products/add_cart/'.$product['id'].'"
                    class="block w-full py-1 text-center text-white bg-blue-800 border border-blue-800 rounded-b hover:bg-transparent hover:text-blue-800 transition">
                    Add to Cart
                </a>
                <!-- product button end -->
            </div>
            ';
        }
        ?>
        <!-- single product end -->
    </div>
    <!-- product wrapper end -->
</div>
<!-- top new arrival end -->

<!-- ad section -->
<div class="container pb-16">
    <a href="#">
        <img src="public/images/banner2.jpg" class="w-full">
    </a>
</div>
<!-- ad section end -->

<!-- top new arrival -->
<div class="container pb-16">
    <h2 class="text-2xl md:text-3xl font-medium text-gray-800 uppercase mb-6 text-center">nike
    </h2>
    <!-- product wrapper -->
    <div class="grid lg:grid-cols-4 sm:grid-cols-2 gap-6">
        <!-- single product -->
        <?php foreach($data['products2'] as $product){
            echo '            
            <div class="group rounded bg-white shadow overflow-hidden">
                <!-- product image -->
                <div class="relative">
                    <img src="public/images/products/'.$product['image'].'" class="w-full lg:max-h-44">
                    <div
                        class="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center gap-2 opacity-0 group-hover:opacity-100 transition">
                        <a href="http://localhost/thebrownies1/products/viewproduct/'.$product['id'].'"
                            class="text-white text-lg w-9 h-9 rounded-full bg-blue-800 hover:bg-gray-800 transition flex items-center justify-center">
                            <i class="fas fa-search"></i>
                        </a>
                        
                    </div>
                </div>
                <!-- product image end -->
                <!-- product content -->
                <div class="pt-4 pb-3 px-4">
                    <a href="http://localhost/thebrownies1/products/viewproduct/'.$product['id'].'">
                        <h4
                            class="uppercase font-medium text-xl mb-2 text-gray-800 hover:text-blue-800 transition">
                            '.$product['name'].'
                        </h4>
                    </a>
                    <div class="flex items-baseline mb-1 space-x-2">
                        <p class="text-xl text-blue-800 font-roboto font-semibold">$'.$product['price'].'</p>
    
                    </div>
    
                </div>
                <!-- product content end -->
                <!-- product button -->
                <a href="http://localhost/thebrownies1/products/add_cart/'.$product['id'].'"
                    class="block w-full py-1 text-center text-white bg-blue-800 border border-blue-800 rounded-b hover:bg-transparent hover:text-blue-800 transition">
                    Add to Cart
                </a>
                <!-- product button end -->
            </div>
            ';
        }
        ?>
        <!-- single product end -->
    </div>
    <!-- product wrapper end -->
</div>
<!-- top new arrival end -->

<?php require_once "mvc/views/footer.php"; ?>