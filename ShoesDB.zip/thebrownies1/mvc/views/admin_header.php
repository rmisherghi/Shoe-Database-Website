<?php
if (
  !isset($_SESSION['email']) || !isset($_SESSION['password']) || empty($_SESSION['email']) || empty($_SESSION['password']) || $_SESSION['email'] !== "admin@gmail.com" || $_SESSION['password'] !== "admin"
) {
  redirect('http://localhost/thebrownies1/users/login');
  session_unset();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin The Brownies</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
  <script>
    $(document).ready(function () {
      $("#myInput").on("keyup", function () {
        var value = $(this).val().toLowerCase();
        $("#myTable tr").filter(function () {
          $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
        });
      });
    });
  </script>
</head>

<body>
  <div class="logo text-center text-4xl p-5 bg-blue-200">The Brownies Admin</div>
  <ul class="flex flex-col border-b bg-gray-100 md:flex-row">
    <li class="-mb-px m-1">
      <a class="bg-gray-200 inline-block border-l border-t border-r rounded-t py-2 px-4 text-blue-700 font-semibold"
        href="http://localhost/thebrownies1/admin/products">Products</a>
    </li>
    <li class="m-1">
      <a class="bg-gray-200 inline-block py-2 px-4 text-blue-500 hover:text-blue-800 font-semibold"
        href="http://localhost/thebrownies1/admin/brands">Brands</a>
    </li>
    <li class="m-1">
      <a class="bg-gray-200 inline-block py-2 px-4 text-blue-500 hover:text-blue-800 font-semibold"
        href="http://localhost/thebrownies1/admin/sizes">Sizes</a>
    </li>
    <li class="m-1">
      <a class="bg-gray-200 inline-block py-2 px-4 text-blue-500 hover:text-blue-800 font-semibold"
        href="http://localhost/thebrownies1/admin/colors">Colors</a>
    </li>
  </ul>
  <!-- component -->