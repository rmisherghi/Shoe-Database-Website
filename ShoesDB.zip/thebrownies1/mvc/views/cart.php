<?php require_once "mvc/views/header.php"; ?>

<!-- breadcrum -->
<div class="py-4 container flex gap-3 items-center">
    <a href="http://localhost/thebrownies1/" class="text-blue-800 text-base">
        <i class="fas fa-home"></i>
    </a>
    <span class="text-sm text-gray-400"><i class="fas fa-chevron-right"></i></span>
    <p class="text-gray-600 font-medium uppercase">Shopping Cart</p>
</div>
<!-- breadcrum end -->

<!-- cart wrapper -->
<div class="container lg:grid grid-cols-12 gap-6 items-start pb-16 pt-4">
    <!-- product cart -->
    <div class="xl:col-span-9 lg:col-span-8">
        <!-- cart title -->
        <div class="bg-gray-200 py-2 pl-12 pr-20 xl:pr-28 mb-4 hidden md:flex">
            <p class="text-gray-600 text-center">Product</p>
            <p class="text-gray-600 text-center ml-auto mr-16 xl:mr-24">Quantity</p>
            <p class="text-gray-600 text-center">Total</p>
        </div>
        <!-- cart title end -->

        <!-- shipping carts -->
        <div class="space-y-4">
            <!-- single cart -->
            <?php
            if (isset($data['products'])) {

                foreach ($data['products'] as $key => $product) {
                    echo '
                   <div
                       class="flex items-center md:justify-between gap-4 md:gap-6 p-4 border border-gray-200 rounded flex-wrap md:flex-nowrap">
                       <!-- cart image -->
                       <div class="w-32 flex-shrink-0">
                           <img src="http://localhost/thebrownies1/public/images/products/' . $product['image'] . '" class="w-full">
                       </div>
                       <!-- cart image end -->
                       <!-- cart content -->
                       <div class="md:w-1/3 w-full">
                           <h2 class="text-gray-800 mb-3 xl:text-xl textl-lg font-medium uppercase">
                               ' . $product['name'] . '
                           </h2>
                           <p class="text-blue-800 font-semibold">$' . $product['price'] . '</p>
                           <p class="text-gray-500">Size: ' . $product['size'] . '</p>
                       </div>
                       <!-- cart content end -->
                       <!-- cart quantity -->
                       <div class="flex border border-gray-300 text-gray-600 divide-x divide-gray-300">
                           <!--<div
                               class="h-8 w-8 text-xl flex items-center justify-center cursor-pointer select-none">
                               -</div>-->
                           <div class="h-8 w-10 flex items-center justify-center">' . $product['quantity'] . '</div>
                          <!-- <div
                               class="h-8 w-8 text-xl flex items-center justify-center cursor-pointer select-none">
                               +</div>-->
                       </div>
                       <!-- cart quantity end -->
                       <div class="ml-auto md:ml-0">
                           <p class="text-blue-800 text-lg font-semibold">$' . $product['total_each'] . '</p>
                       </div>
                       <a href="http://localhost/thebrownies1/products/delete_cart/' . $key . '">
                       <div class="text-gray-600 hover:text-blue-800 cursor-pointer">
                           <i class="fas fa-trash"></i>
                       </div>
                       </a>
                   </div>
                   ';
                }
            } else {
                echo 'CART IS EMPTY. LET\'S SHOPPING';
            }
            ?>
            <!-- single cart end -->
        </div>
        <!-- shipping carts end -->
    </div>
    <!-- product cart end -->
    <!-- order summary -->
    <div
        class="xl:col-span-3 lg:col-span-4 border border-gray-200 px-4 py-4 rounded mt-6 lg:mt-0 lg:mb-40">
        <h4 class="text-gray-800 text-lg mb-4 font-medium uppercase">ORDER SUMMARY</h4>
        <div class="space-y-1 text-gray-600 pb-3 border-b border-gray-200">
            <div class="flex justify-between font-medium">
                <p>Subtotal</p>
                <p>$
                    <?php
                if (isset($data['final_price'])) {
                    echo $data['final_price'];
                } else {
                    echo 0;
                }
                ?>
                </p>
            </div>
            <div class="flex justify-between">
                <p>Delivery</p>
                <p>Free</p>
            </div>
            <div class="flex justify-between">
                <p>Tax</p>
                <p>Free</p>
            </div>
        </div>
        <div class="flex justify-between my-3 text-gray-800 font-semibold uppercase">
            <h4>Total</h4>
            <h4>$
                <?php
            if (isset($data['final_price'])) {
                echo $data['final_price'];
            } else {
                echo 0;
            }
            ?>
            </h4>
        </div>

        <!-- searchbar -->
        <div class="flex mb-5">
            <input type="text"
                class="pl-4 w-full border border-r-0 border-blue-800 py-2 px-3 rounded-l-md focus:ring-blue-800 focus:border-blue-800 text-sm"
                placeholder="Coupon">
            <button type="submit"
                class="bg-blue-800 border border-blue-800 text-white px-5 font-medium rounded-r-md hover:bg-transparent hover:text-blue-800 transition text-sm font-roboto">
                Apply
            </button>
        </div>
        <!-- searchbar end -->

        <!-- checkout -->
        <a href="checkout.html" class="bg-blue-800 border border-blue-800 text-white px-4 py-3 font-medium rounded-md uppercase hover:bg-transparent
             hover:text-blue-800 transition text-sm w-full block text-center">
            Process to checkout
        </a>
        <!-- checkout end -->
    </div>
    <!-- order summary end -->
</div>
<!-- cart wrapper end -->


<script>
    let menuBar = document.querySelector('#menuBar')
    let mobileMenu = document.querySelector('#mobileMenu')
    let closeMenu = document.querySelector('#closeMenu')

    menuBar.addEventListener('click', function () {
        mobileMenu.classList.remove('hidden')
    })

    closeMenu.addEventListener('click', function () {
        mobileMenu.classList.add('hidden')
    })
</script>
<?php require_once "mvc/views/footer.php"; ?>