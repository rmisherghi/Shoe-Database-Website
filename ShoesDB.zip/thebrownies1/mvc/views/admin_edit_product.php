<?php require_once "admin_header.php";
// var_dump($data['brand']);
?>
<div class="flex justify-center">
    <div class="block p-6 rounded-lg shadow-lg bg-white max-w-3xl">
        <p class="text-lg m-3">Edit product</p>
        <form
            action="http://localhost/thebrownies1/admin/get_edit_product/<?= $data['product'][0]['id'] ?>"
            enctype="multipart/form-data" method="POST">
            <div class="form-group mb-6">
                <label for="exampleInputEmail1"
                    class="form-label inline-block mb-2 text-gray-700">Name</label>
                <input required type="text" class="form-control
            block
            w-full
            px-3
            py-1.5
            text-base
            font-normal
            text-gray-700
            bg-white bg-clip-padding
            border border-solid border-gray-300
            rounded
            transition
            ease-in-out
            m-0
            focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none"
                    id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter name"
                    value="<?= $data['product'][0]['name'] ?>" name="shoes_name">
            </div>
            <div class="form-group mb-6">
                <label for="exampleInputPassword1"
                    class="form-label inline-block mb-2 text-gray-700">Price</label>
                <input name="price" required type="number" step="0.1" class="form-control block
            w-full
            px-3
            py-1.5
            text-base
            font-normal
            text-gray-700
            bg-white bg-clip-padding
            border border-solid border-gray-300
            rounded
            transition
            ease-in-out
            m-0
            focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none"
                    id="exampleInputPassword1" placeholder="Price"
                    value="<?= $data['product'][0]['price'] ?>">
            </div>
            <div class="form-group mb-6">
                <label for="exampleInputPassword1"
                    class="form-label inline-block mb-2 text-gray-700">Detail</label>
                <textarea required class="form-control block
            w-full
            px-3
            py-1.5
            text-base
            font-normal
            text-gray-700
            bg-white bg-clip-padding
            border border-solid border-gray-300
            rounded
            transition
            ease-in-out
            m-0
            focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none"
                    id="exampleInputPassword1" placeholder="Detail" rows="4"
                    name="detail"><?= $data['product'][0]['detail'] ?></textarea>
            </div>
            <div class="form-group mb-6">
                <label for="exampleInputPassword1"
                    class="form-label inline-block mb-2 text-gray-700">Image</label>
                <input type="file" class="form-control block
            w-full
            px-3
            py-1.5
            text-base
            font-normal
            text-gray-700
            bg-white bg-clip-padding
            border border-solid border-gray-300
            rounded
            transition
            ease-in-out
            m-0
            focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none"
                    id="exampleInputPassword1" placeholder="Price" name="image">
            </div>

            <div class="flex justify-center">
                <div class="mb-3 xl:w-96">
                    <label>Brand name</label>
                    <select name="brand_id" required class="form-select appearance-none
      block
      w-full
      px-3
      py-1.5
      text-base
      font-normal
      text-gray-700
      bg-white bg-clip-padding bg-no-repeat
      border border-solid border-gray-300
      rounded
      transition
      ease-in-out
      m-0
      focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none"
                        aria-label="Default select example">
                        <?php foreach ($data['brands'] as $brand) {
                            if ($brand['brand_id'] == $data['brand'][0]['brand_id']) {
                                echo '
                                <option value="' . $brand['brand_id'] . '" class="uppercase" selected>' . $brand['brand_name'] . '</option>
                                ';
                            } else {
                                echo '
                                <option value="' . $brand['brand_id'] . '" class="uppercase">' . $brand['brand_name'] . '</option>
                                ';
                            }
                        } ?>
                    </select>
                </div>
            </div>

            <div class="flex justify-center">
                <div class="mb-3 xl:w-96">
                    <label>Color</label>
                    <select name="color_id" class="form-select appearance-none
      block
      w-full
      px-3
      py-1.5
      text-base
      font-normal
      text-gray-700
      bg-white bg-clip-padding bg-no-repeat
      border border-solid border-gray-300
      rounded
      transition
      ease-in-out
      m-0
      focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none"
                        aria-label="Default select example" required>
                        <?php foreach ($data['colors'] as $color) {
                            if ($color['color_id'] == $data['color'][0]['color_id']) {
                                echo '
                                <option value="' . $color['color_id'] . '" class="uppercase" selected>' . $color['color_name'] . '</option>
                                ';
                            } else {
                                echo '
                                <option value="' . $color['color_id'] . '" class="uppercase">' . $color['color_name'] . '</option>
                                ';
                            }
                        } ?>
                    </select>
                </div>
            </div>

            <h3 class="mb-1 mt-2 text-gray-900 dark:text-white">Sizes</h3>
            <ul
                class="items-center w-full text-sm font-medium text-gray-900 bg-white rounded-lg border border-gray-200 sm:flex dark:bg-gray-700 dark:border-gray-600 dark:text-white">
                <?php
                $id_sizes = [];
                foreach ($data['sizes'] as $value) {
                    array_push($id_sizes, $value['id']);
                }
                $id_shoes_sizes = [];
                foreach ($data['size_number'] as $value) {
                    array_push($id_shoes_sizes, $value['size_id']);
                }
                $same_size_id = array_intersect($id_sizes, $id_shoes_sizes);

                foreach ($data['sizes'] as $size) {
                    echo '
                    <li class="w-full border-b border-gray-200 sm:border-b-0 sm:border-r dark:border-gray-600">
                        <div class="flex items-center pl-3">
                        <input name="sizes[]" id="' . $size['id'] . '" type="checkbox" value="' . $size['id'] . '" class="w-4 h-4 text-blue-600 bg-gray-100 rounded border-gray-300 focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-700 focus:ring-2 dark:bg-gray-600 dark:border-gray-500"';
                    if (in_array($size['id'], $same_size_id)) {
                        echo 'checked';
                    }
                    echo '>
                        <label for="' . $size['id'] . '" class="py-3 ml-2 w-full text-sm font-medium text-gray-900 dark:text-gray-300">' . $size['number'] . '</label>
                        </div>
                        </li>
                        ';
                }

                ?>
            </ul>

            <button type="submit" class="
            mt-3
          px-6
          py-2.5
          bg-blue-600
          text-white
          font-medium
          text-xs
          leading-tight
          uppercase
          rounded
          shadow-md
          hover:bg-blue-700 hover:shadow-lg
          focus:bg-blue-700 focus:shadow-lg focus:outline-none focus:ring-0
          active:bg-blue-800 active:shadow-lg
          transition
          duration-150
          ease-in-out">Edit product</button>
        </form>
    </div>
</div>