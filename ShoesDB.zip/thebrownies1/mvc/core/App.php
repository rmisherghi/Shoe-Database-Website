<?php
require_once "mvc/include/until.php";
class App
{

    // set default returnt no matter what user enter in url 
    protected $controller = "products";
    protected $action = "home";
    protected $params = [];

    function __construct()
    {

        $arr = $this->UrlProcess();

        // Controller
        if (file_exists("./mvc/controllers/" . $arr[0] . ".php")) {
            $this->controller = $arr[0];
            unset($arr[0]);
        }
        require_once "./mvc/controllers/" . $this->controller . ".php";
        $this->controller = new $this->controller;

        // Action
        if (isset($arr[1])) {
            if (method_exists($this->controller, $arr[1])) {
                $this->action = $arr[1];
            }
            unset($arr[1]);
        }

        // Params
        $this->params = $arr ? array_values($arr) : [];

        call_user_func_array([$this->controller, $this->action], $this->params);


    }

    // return an arr with each element is cut from url a/b/c -> arr 
    function UrlProcess()
    {
        if (isset($_GET["url"])) {
            return explode("/", filter_var(trim($_GET["url"], "/")));
        }
    }

}
?>