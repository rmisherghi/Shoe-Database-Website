<?php

class DB
{
    public $db;
    protected $servername = "localhost";
    protected $username = "root";
    protected $password = "";
    protected $dbname = "shoes_v2";

    function __construct()
    {
        $this->db = new PDO("mysql:host={$this->servername};dbname={$this->dbname}", $this->username, $this->password);
        // echo "Connected successfully";
        if (!$this->db) {
            print_r($this->db->errorCode());
        }
    }

    
}

?>