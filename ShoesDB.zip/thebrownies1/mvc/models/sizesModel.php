<?php
require_once "mvc/core/DB.php"; 

class sizesModel extends DB{

    public function getAllsizes(){
        $st = $this->db->prepare('SELECT * FROM sizes');
        $st -> execute();
        return $st -> fetchAll(PDO::FETCH_ASSOC);
    }

    public function getOnesizeById($size_id){
        $st = $this->db->prepare("SELECT * FROM sizes WHERE id='{$size_id}'");
        $st -> execute();
        return $st -> fetchAll(PDO::FETCH_ASSOC);
    }

    public function getShoesIdby($size_id)
    {
        $st = $this->db->prepare("SELECT * FROM sizes_specific_shoes WHERE size_id IN ('" . $size_id . "')");
        $st -> execute();
        return $st -> fetchAll(PDO::FETCH_ASSOC);
    }

    public function getSizebyId($shoes_id){
        $st = $this->db->prepare("SELECT * FROM sizes_specific_shoes WHERE specific_shoes_id IN ('" . $shoes_id . "')");
        $st -> execute();
        return $st -> fetchAll(PDO::FETCH_ASSOC);
    }

    public function getSizenumberById($id){
        $st = $this->db->prepare("SELECT * FROM sizes WHERE id IN ('" . $id . "')");
        $st -> execute();
        return $st -> fetchAll(PDO::FETCH_ASSOC);
    }

    public function get_shoes_sizes(){
        $st = $this->db->prepare('SELECT * FROM sizes_specific_shoes');
        $st -> execute();
        return $st -> fetchAll(PDO::FETCH_ASSOC);
    }

    function get_new_shoes_size($size_id, $shoes_id){
        $st = $this->db->prepare("INSERT INTO `sizes_specific_shoes` (`size_shoes_id`, `size_id`, `specific_shoes_id`) VALUES (NULL, '{$size_id}', '{$shoes_id}')");
        $st -> execute();
    }

    function delete_shoes_size($size_id, $shoes_id){
        $st = $this->db->prepare("DELETE FROM sizes_specific_shoes WHERE `sizes_specific_shoes`.`size_id` = '{$size_id}' AND `sizes_specific_shoes`.`specific_shoes_id` = '{$shoes_id}'");
        $st -> execute();
    }

    function get_new_size($number){
        $st = $this->db->prepare("INSERT INTO `sizes` (`id`, `number`) VALUES (NULL, '{$number}');");
        $st -> execute();
    }

    function delete_size($size_id){
        $st = $this->db->prepare("DELETE FROM sizes WHERE `sizes`.`id` = '{$size_id}'");
        $st -> execute();
    }

    function update_size($size_id, $number){
        $st = $this->db->prepare("UPDATE `sizes` SET `number` = '{$number}' WHERE `sizes`.`id` = '{$size_id}'");
        $st -> execute();
    }
}
?>