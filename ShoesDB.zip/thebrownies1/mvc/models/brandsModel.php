<?php
require_once "mvc/core/DB.php";

class brandsModel extends DB{

    public function getAllBrands(){
        $st = $this->db->prepare('SELECT * FROM brands');
        $st -> execute();
        return $st -> fetchAll(PDO::FETCH_ASSOC);
    }

    public function adminBrands($brand_condition){
        $st = $this->db->prepare("SELECT * FROM brands WHERE brand_name LIKE '%{$brand_condition}%' OR brand_id LIKE '%{$brand_condition}%'");
        $st -> execute();
        return $st -> fetchAll(PDO::FETCH_ASSOC);
    }

    public function getIdBrand($brand){
        $st = $this->db->prepare("SELECT * FROM brands WHERE brand_name = '{$brand}'");
        $st -> execute();
        $brandId = $st -> fetchAll(PDO::FETCH_ASSOC);
        return $brandId[0]['brand_id'];
    }

    public function getNameBrandfromId($brand_id){
        $st = $this->db->prepare("SELECT * FROM brands WHERE brand_id = '{$brand_id}'");
        $st -> execute();
        $brandId = $st -> fetchAll(PDO::FETCH_ASSOC);
        return $brandId[0]['brand_name'];
    }

    public function getBrandfromId($brand_id){
        $st = $this->db->prepare("SELECT * FROM brands WHERE brand_id = '{$brand_id}'");
        $st -> execute();
        return $st -> fetchAll(PDO::FETCH_ASSOC);
    }

    public function getNewBrand($brand_name, $image_id){
        $st = $this->db->prepare("INSERT INTO `brands` (`brand_id`, `brand_name`, `image`) VALUES (NULL, '{$brand_name}', 'brand{$image_id}.jpg');");
        $st -> execute();
    }

    public function getLastIdBrand(){
        $st = $this->db->prepare("SELECT * FROM brands
        WHERE brand_id = (SELECT MAX(brand_id) FROM brands)");
        $st -> execute();
        $brandId = $st -> fetchAll(PDO::FETCH_ASSOC);
        return $brandId[0]['brand_id'];
    }

    public function delete_brand($brand_id){
        $st = $this->db->prepare("DELETE FROM `brands` WHERE `brands`.`brand_id` = '{$brand_id}'");
        $st -> execute();
    }

    public function updateBrandwithImage($brand_id,$brand_name){
        $st = $this->db->prepare("UPDATE `brands` SET `brand_name` = '{$brand_name}', `image` = 'brand{$brand_id}.jpg' WHERE `brands`.`brand_id` = {$brand_id};");
        $st -> execute();
    }
    
    public function updateBrandnoImage($brand_id,$brand_name){
        $st = $this->db->prepare("UPDATE `brands` SET `brand_name` = '{$brand_name}' WHERE `brands`.`brand_id` = {$brand_id};");
        $st -> execute();
    }
}
?>