<?php
require_once "mvc/core/DB.php";

class colorsModel extends DB{

    public function getAllColors(){
        $st = $this->db->prepare('SELECT * FROM colors');
        $st -> execute();
        return $st -> fetchAll(PDO::FETCH_ASSOC);
    }

    public function adminColors($color_condition){
        $st = $this->db->prepare("SELECT * FROM colors WHERE color_name LIKE '%{$color_condition}%' OR color_id LIKE '%{$color_condition}%'");
        $st -> execute();
        return $st -> fetchAll(PDO::FETCH_ASSOC);
    }

    public function getIdcolor($color){
        $st = $this->db->prepare("SELECT * FROM colors WHERE color_name = '{$color}'");
        $st -> execute();
        $colorId = $st -> fetchAll(PDO::FETCH_ASSOC);
        return $colorId[0]['color_id'];
    }

    public function getNameColorbyId($id_color){
        $st = $this->db->prepare("SELECT * FROM colors WHERE color_id = '{$id_color}'");
        $st -> execute();
        $colorName = $st -> fetchAll(PDO::FETCH_ASSOC);
        return $colorName[0]['color_name'];
    }

    public function getColorbyId($id_color){
        $st = $this->db->prepare("SELECT * FROM colors WHERE color_id = '{$id_color}'");
        $st -> execute();
        return $st -> fetchAll(PDO::FETCH_ASSOC);
    }

    public function get_new_color($color_name){
        $st = $this->db->prepare("INSERT INTO `colors` (`color_id`, `color_name`) VALUES (NULL, '{$color_name}')");
        $st -> execute();
    }

    public function delete_color($color_id){
        $st = $this->db->prepare("DELETE FROM `colors` WHERE `colors`.`color_id` = '{$color_id}'");
        $st -> execute();
    }

    public function updateColor($color_id,$color_name){
        $st = $this->db->prepare("UPDATE `colors` SET `color_name` = '{$color_name}' WHERE `colors`.`color_id` = {$color_id};");
        $st -> execute();
    }
}
?>