<?php
require_once "mvc/core/DB.php"; 

class productsModel extends DB{

    public function getAllshoes(){
        $st = $this->db->prepare('SELECT * FROM specific_shoes');
        $st -> execute();
        return $st -> fetchAll(PDO::FETCH_ASSOC);
    }

    public function getShoesByBrandId($id)
    {           
        $st = $this->db->prepare("SELECT * FROM `specific_shoes` WHERE `brand_id` = '{$id}'");
        $st -> execute();
        return $st -> fetchAll(PDO::FETCH_ASSOC);    
    }

    public function getShoesByBrandIdExcept($brand_id, $shoes_id){
        $st = $this->db->prepare("SELECT * FROM specific_shoes WHERE brand_id = '{$brand_id}' AND NOT id = '{$shoes_id}'");
        $st -> execute();
        return $st -> fetchAll(PDO::FETCH_ASSOC);
    }

    public function adminProducts($condition){
        $st = $this->db->prepare("SELECT specific_shoes.id, specific_shoes.name, specific_shoes.price, specific_shoes.image, specific_shoes.detail, brands.brand_name, colors.color_name FROM specific_shoes INNER JOIN brands ON specific_shoes.brand_id = brands.brand_id INNER JOIN colors ON specific_shoes.color_id = colors.color_id WHERE specific_shoes.name LIKE '%{$condition}%' OR colors.color_name LIKE '%{$condition}%' OR brands.brand_name LIKE '%{$condition}%'");
        $st -> execute();
        return $st -> fetchAll(PDO::FETCH_ASSOC);
    }

    public function runQuery($query){
        $st = $this->db->prepare($query);
        $st -> execute();
        return $st -> fetchAll(PDO::FETCH_ASSOC); 
    }

    public function getShoesbyId($shoes_id){
        $st = $this->db->prepare("SELECT * FROM `specific_shoes` WHERE `id` = '{$shoes_id}'");
        $st -> execute();
        return $st -> fetchAll(PDO::FETCH_ASSOC); 
    }

    public function get_new_product($brand_id, $name, $price, $image, $detail, $color_id){
        $st = $this->db->prepare("INSERT INTO `specific_shoes` (`id`, `brand_id`, `name`, `price`, `image`, `detail`, `color_id`) VALUES (NULL, '{$brand_id}', '{$name}', '{$price}', '{$image}', '{$detail}', '{$color_id}');");
        $st -> execute();
    }

    public function delete_product($shoes_id){
        $st = $this->db->prepare("DELETE FROM specific_shoes WHERE `specific_shoes`.`id` = '{$shoes_id}'");
        $st -> execute();
    }

    public function getLastShoesId(){
        $st = $this->db->prepare("SELECT * FROM specific_shoes
        WHERE `specific_shoes`.`id` = (SELECT MAX(id) FROM specific_shoes)");
        $st -> execute();
        $shoesId = $st -> fetchAll(PDO::FETCH_ASSOC);
        return $shoesId[0]['id'];
    }

    public function updateProductnoimage($shoes_id,$shoes_name,$price,$detail,$color_id){
        $st = $this->db->prepare("UPDATE `specific_shoes` SET `name` = '{$shoes_name}', `price` = '{$price}', `detail` = '{$detail}', `color_id` = '{$color_id}' WHERE `specific_shoes`.`id` = '{$shoes_id}';");
        $st -> execute();
    }

    public function updateProductwithimage($shoes_id,$shoes_name,$price,$detail,$color_id,$image){
        $st = $this->db->prepare("UPDATE `specific_shoes` SET `name` = '{$shoes_name}', `price` = '{$price}', `detail` = '{$detail}', `color_id` = '{$color_id}', `image` = '{$image}' WHERE `specific_shoes`.`id` = '{$shoes_id}';");
        $st -> execute();
    }
}
?>