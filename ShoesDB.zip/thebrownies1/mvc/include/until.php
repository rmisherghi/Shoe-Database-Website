<?php
function redirect($url)
{
  header("Location: $url");
  exit();
}

function getAdmin($email, $password)
{
    $_SESSION['email'] = $email;
    $_SESSION['password'] = $password;
}

?>